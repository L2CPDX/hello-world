# Friday

* 6:00pm - Git: Merge Conflicts
 * Did you push your code last night?
 * Branch: git checkout -b friday
 * Add a new file: friday.md
 * MERGE CONFLICTS!!!!
   * Modify line 1 of README.md in friday
   * Commit changes; checkout master; modify line 1 of README.md in master
   * Look at history in master:
     * git log
     * git show [SHA]
   * Look at history in friday:
     * git checkout friday
     * git log
     * git show [SHA]
  * Merge friday into master and look at merge conflict
  * How to resolve a merge conflict
* 6:30pm - JavaScript: Functions & console.log
  * Use [code/friday.html](/code/friday.html) and [code/friday.js](/code/friday.js)
* 7:15pm - Prework (you should be 100% complete by the end of class)
* 8:30pm - Recap, Q&A

[Back to main README](/README.md)
