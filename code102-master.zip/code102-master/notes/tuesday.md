Tuesday Notes:

Concatenating: adding strings together

Operators and Types:

Operators: 
- \+ 
- \- 
- / 
- \* 
- %

comparison: 
- < 
- \> 
- == 
- === 

<br>
assignment:

- =




op: + - when used with a string, ('this is a string') usage changes. 5+5 returns 10, but '5'+'5' returns 55.

op: == compares only the value

op: === compares both the value and the type

op: = is assignment, it DOES NOT mean "equals". It is for assigning values to variables.



Types: numbers, strings, boolean (true, false), function 

Consoles are REPLs - Read Evaluate Print Loop

