# Working in Atom

## Getting Started
1. Open your class repo in Atom: **File > Add project folder...**
2. Close extra panes/windows
3. Toggle your file view sidebar with Cmd-M / Ctrl-M
4. Create a file for Monday in the `/notes` folder (call the file `monday.md`)

## Installing a Terminal Plugin
1. **Atom > Preferences** (or Cmd-, / Ctrl-,)
2. Go to **Install** (NOT Packages)
3. In the search box, type: platformio-ide-terminal
4. Install the package
5. Return to your notes file for Monday
6. Open a terminal window by clicking the little terminal icon in the bottom toolbar, or by using Cmd-Shift-T / Ctrl-Shift-T
