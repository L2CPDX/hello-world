## vi practice worksheet

For a list of commands, view the vi cheat sheet in the resources directory in this reposiorty

After completing each of these tasks, press the `<esc>` key to return to Command mode.

#### Go to a specific line, and add to end of line.
Add your name to the following line.  Position the cursor on line `n` by entering `nG` and pressing enter, then type `A`

Hello my name is 

#### Insert a line
move your cursor using the `j` and `k` keys to the line with `two`, then press `o` and add the missing list item.

* one
* two
* four

#### Find, delete and add text at cursor 
position the cursor at `West` by typing `/West` and pressing enter.  Press `n` until you're at the incorrect word. Delete the word by typing `dw`.  Then press `i` and enter the proper descriptor.

Code Fellows PDX is located on the West side of the river.

#### 
