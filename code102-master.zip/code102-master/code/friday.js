// In today's assignment, you'll "refactor" the code from yesterday.
// After each TODO, once you get the code working, stop and add/commit
// your changes to your repository.

// TODO: Copy in your completed code from Thursday.

// TODO: Refactor all the code into a single big function
//       called dayApp(). Be sure to work incrementally!

// TODO: What happens if you reload the page now?

// TODO: Add one line of code that calls your new function.
//       Now what happens when you reload the page?

// TODO: Refactor the math that gets a random day number
//       into a function called getDayNumber().

// TODO: Refactor the if/else if/else block that comments
//       on each day into this function:
function remarkOnDay(day) {

}
